    </div>
  </main>
  <footer class="auth-footer text-center mt-4">
            <p class="small text-muted">&copy; <?php echo date('Y'); ?> Admin Elect. Tous droits réservés.</p>
  </footer>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo ASSET_PATH; ?>bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo ASSET_PATH; ?>js/auth.js"></script>
</body>
</html> 
