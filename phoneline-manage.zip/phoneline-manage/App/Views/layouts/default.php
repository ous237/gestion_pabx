<?php
$stylesheet = "/assets/css/style.css";
$header = APP_PATH . "/Views/layouts/partials/header.php";
$footer = APP_PATH . "/Views/layouts/partials/footer.php";

include APP_PATH . "/Views/layouts/base.php";
