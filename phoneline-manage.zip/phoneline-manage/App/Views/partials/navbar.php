<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="/">Gestion Stagiaires</a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="/dashboard">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="/stagiaires">Stagiaires</a></li>
                <li class="nav-item"><a class="nav-link" href="/tuteurs">Tuteurs</a></li>
                <li class="nav-item"><a class="nav-link" href="/missions">Missions</a></li>
                <li class="nav-item"><a class="nav-link" href="/auth/logout">Déconnexion</a></li>
            </ul>
        </div>
    </div>
</nav>
