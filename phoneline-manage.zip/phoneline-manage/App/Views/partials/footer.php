<footer class="bg-dark text-light text-center py-3 mt-5">
    <p>&copy; 2025 Camrail. Tous droits réservés.</p>
</footer>
<script src="/assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>
