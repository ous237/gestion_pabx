<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Stagiaires</title>
    <link rel="stylesheet" href="/assets/css/bootstrap.min.css">
</head>
<body>
<?php include_once __DIR__ . '/navbar.php'; ?>
