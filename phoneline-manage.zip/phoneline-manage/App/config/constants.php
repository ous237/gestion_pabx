<?php
define('APP_URL', 'http://localhost:8000/gestion-lignes');
define('APP_NAME', 'Gestion des lignes- CAMRAIL');
define('APP_EMAIL', 'camrail@gmail.com');
define('APP_VERSION', '1.0.0');
define('BASE_PATH', dirname(dirname(__DIR__)) . '/');
define('ASSET_PATH', dirname(dirname(__DIR__)) . '/public/');
define('APP_PATH', BASE_PATH . 'App');
define('FPDF_FONTPATH',   'helvetica');
// define('VIEW_PATH', __DIR__ . '../../');


